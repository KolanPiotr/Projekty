﻿namespace Lab02.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Index { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Specialty { get; set; }
    }
}
