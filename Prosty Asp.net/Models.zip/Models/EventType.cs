﻿namespace Lab02.Models {
    public class EventType {
        public string Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<MatchEvent> MatchEvents { get; set; }
    }
}
