﻿namespace Lab02.Models {
    public class MatchEvent {
        public int Id {  get; set; }
        public int Minute { get; set; }
        public virtual EventType EventType { get; set; }
        public virtual Match Match { get; set; }
        public virtual MatchPlayer? MatchPlayer { get; set; }
    }
}
