using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AS_lab1_gr2.Views
{
    public class _ViewsStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
