﻿namespace Lab02.Views.Player {
    public class PositionViewModel {
        public string name {  get; set; }
    }
}
